import React, { Component, Fragment } from 'react';

export default class News extends Component {
  render() {
    return <div>dddd</div>;
  }
}
