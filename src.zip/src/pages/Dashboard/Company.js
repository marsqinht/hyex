import { Component } from 'react';
import Banner from './Banner';

export default class Fawen extends Component {
  render() {
    return (
      <div>
        <Banner />
      </div>
    )
  }
}