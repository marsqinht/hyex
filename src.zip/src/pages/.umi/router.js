import React from 'react';
import { Router as DefaultRouter, Route, Switch } from 'react-router-dom';
import dynamic from 'umi/dynamic';
import renderRoutes from 'umi/lib/renderRoutes';
import history from '@tmp/history';
import RendererWrapper0 from '/Users/qinhaitao/Documents/hyex/src/pages/.umi/LocaleWrapper.jsx';
import _dvaDynamic from 'dva/dynamic';

const Router = require('dva/router').routerRedux.ConnectedRouter;

const routes = [
  {
    path: '/',
    component: __IS_BROWSER
      ? _dvaDynamic({
          component: () =>
            import(/* webpackChunkName: "layouts__BasicLayout" */ '../../layouts/BasicLayout'),
          LoadingComponent: require('/Users/qinhaitao/Documents/hyex/src/components/PageLoading/index')
            .default,
        })
      : require('../../layouts/BasicLayout').default,
    routes: [
      {
        path: '/',
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import(/* webpackChunkName: 'p__Dashboard__models__activities.js' */ '/Users/qinhaitao/Documents/hyex/src/pages/Dashboard/models/activities.js').then(
                  m => {
                    return { namespace: 'activities', ...m.default };
                  },
                ),
                import(/* webpackChunkName: 'p__Dashboard__models__chart.js' */ '/Users/qinhaitao/Documents/hyex/src/pages/Dashboard/models/chart.js').then(
                  m => {
                    return { namespace: 'chart', ...m.default };
                  },
                ),
                import(/* webpackChunkName: 'p__Dashboard__models__monitor.js' */ '/Users/qinhaitao/Documents/hyex/src/pages/Dashboard/models/monitor.js').then(
                  m => {
                    return { namespace: 'monitor', ...m.default };
                  },
                ),
              ],
              component: () =>
                import(/* webpackChunkName: "p__Dashboard__Home" */ '../Dashboard/Home'),
              LoadingComponent: require('/Users/qinhaitao/Documents/hyex/src/components/PageLoading/index')
                .default,
            })
          : require('../Dashboard/Home').default,
        authority: ['admin', 'user'],
        exact: true,
      },
      {
        path: '/dashboard',
        name: '公共事务',
        icon: 'bank',
        routes: [
          {
            path: '/dashboard/huyi',
            name: '会议信息',
            component: __IS_BROWSER
              ? _dvaDynamic({
                  component: () =>
                    import(/* webpackChunkName: "p__Huiyi" */ '../Huiyi'),
                  LoadingComponent: require('/Users/qinhaitao/Documents/hyex/src/components/PageLoading/index')
                    .default,
                })
              : require('../Huiyi').default,
            exact: true,
          },
          {
            path: '/dashboard/yuanong',
            name: '员工信息',
            component: __IS_BROWSER
              ? _dvaDynamic({
                  component: () =>
                    import(/* webpackChunkName: "p__Employee" */ '../Employee'),
                  LoadingComponent: require('/Users/qinhaitao/Documents/hyex/src/components/PageLoading/index')
                    .default,
                })
              : require('../Employee').default,
            exact: true,
          },
          {
            path: '/dashboard/zizhi',
            name: '资质信息',
            component: __IS_BROWSER
              ? _dvaDynamic({
                  component: () =>
                    import(/* webpackChunkName: "p__Zizhi" */ '../Zizhi'),
                  LoadingComponent: require('/Users/qinhaitao/Documents/hyex/src/components/PageLoading/index')
                    .default,
                })
              : require('../Zizhi').default,
            exact: true,
          },
          {
            path: '/dashboard/hueixunyi',
            name: '培训信息',
            component: __IS_BROWSER
              ? _dvaDynamic({
                  component: () =>
                    import(/* webpackChunkName: "p__Peixun" */ '../Peixun'),
                  LoadingComponent: require('/Users/qinhaitao/Documents/hyex/src/components/PageLoading/index')
                    .default,
                })
              : require('../Peixun').default,
            exact: true,
          },
          {
            path: '/dashboard/ananbvjglfddysis',
            name: '车辆信息',
            component: __IS_BROWSER
              ? _dvaDynamic({
                  component: () =>
                    import(/* webpackChunkName: "p__Car" */ '../Car'),
                  LoadingComponent: require('/Users/qinhaitao/Documents/hyex/src/components/PageLoading/index')
                    .default,
                })
              : require('../Car').default,
            exact: true,
          },
          {
            path: '/dashboard/analfddysis',
            name: 'HYEC新闻',
            component: __IS_BROWSER
              ? _dvaDynamic({
                  component: () =>
                    import(/* webpackChunkName: "p__News" */ '../News'),
                  LoadingComponent: require('/Users/qinhaitao/Documents/hyex/src/components/PageLoading/index')
                    .default,
                })
              : require('../News').default,
            exact: true,
          },
          {
            path: '/dashboard/dsfds',
            name: '公司发文',
            component: __IS_BROWSER
              ? _dvaDynamic({
                  component: () =>
                    import(/* webpackChunkName: "p__Company" */ '../Company'),
                  LoadingComponent: require('/Users/qinhaitao/Documents/hyex/src/components/PageLoading/index')
                    .default,
                })
              : require('../Company').default,
            exact: true,
          },
          {
            path: '/dashboard/detail/:page/:index',
            name: 'newsDtetail',
            hideInMenu: true,
            component: __IS_BROWSER
              ? _dvaDynamic({
                  component: () =>
                    import(/* webpackChunkName: "p__News__detail" */ '../News/detail'),
                  LoadingComponent: require('/Users/qinhaitao/Documents/hyex/src/components/PageLoading/index')
                    .default,
                })
              : require('../News/detail').default,
            exact: true,
          },
          {
            path: '/dashboard',
            name: '党群工作',
            icon: 'bank',
            routes: [
              {
                path: '/dashboard/analssysis',
                name: '党的建设',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../News/party'),
                      LoadingComponent: require('/Users/qinhaitao/Documents/hyex/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../News/party').default,
                exact: true,
              },
              {
                path: '/dashboard/huayi',
                name: '华谊工程',
                hideInMenu: true,
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../News/huayi'),
                      LoadingComponent: require('/Users/qinhaitao/Documents/hyex/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../News/huayi').default,
                exact: true,
              },
              {
                path: '/dashboard/zhiduHuibian',
                name: '制度汇编',
                hideInMenu: true,
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../News/zhiduHuibian'),
                      LoadingComponent: require('/Users/qinhaitao/Documents/hyex/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../News/zhiduHuibian').default,
                exact: true,
              },
              {
                path: '/dashboard/analssyddsis',
                name: '纪检监察',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../News/jijian'),
                      LoadingComponent: require('/Users/qinhaitao/Documents/hyex/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../News/jijian').default,
                exact: true,
              },
              {
                component: () =>
                  React.createElement(
                    require('/Users/qinhaitao/Documents/hyex/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                      .default,
                    { pagesPath: 'src/pages', hasRoutesInConfig: true },
                  ),
              },
            ],
          },
          {
            component: () =>
              React.createElement(
                require('/Users/qinhaitao/Documents/hyex/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                  .default,
                { pagesPath: 'src/pages', hasRoutesInConfig: true },
              ),
          },
        ],
      },
      {
        path: '/zhiliang',
        name: '质量管理',
        icon: 'insurance',
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__Zhiliang" */ '../Zhiliang'),
              LoadingComponent: require('/Users/qinhaitao/Documents/hyex/src/components/PageLoading/index')
                .default,
            })
          : require('../Zhiliang').default,
        exact: true,
      },
      {
        path: '/jishu',
        name: '技术管理',
        icon: 'tool',
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__Jishu" */ '../Jishu'),
              LoadingComponent: require('/Users/qinhaitao/Documents/hyex/src/components/PageLoading/index')
                .default,
            })
          : require('../Jishu').default,
        exact: true,
      },
      {
        path: '/HSE',
        name: 'HSE管理',
        icon: 'smile',
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__Hse" */ '../Hse'),
              LoadingComponent: require('/Users/qinhaitao/Documents/hyex/src/components/PageLoading/index')
                .default,
            })
          : require('../Hse').default,
        exact: true,
      },
      {
        path: '/dd',
        name: '标准与规范',
        icon: 'highlight',
        routes: [
          {
            name: '公司工作手册',
            path: 'http://www1.hyec.com:8501/Index.aspx',
            target: '_blank',
            exact: true,
          },
          {
            path: '/dd/standard',
            name: '常用文档模板',
            component: __IS_BROWSER
              ? _dvaDynamic({
                  component: () =>
                    import(/* webpackChunkName: "p__Standard__index" */ '../Standard/index'),
                  LoadingComponent: require('/Users/qinhaitao/Documents/hyex/src/components/PageLoading/index')
                    .default,
                })
              : require('../Standard/index').default,
            exact: true,
          },
          {
            path: '/dd/s',
            name: '技术标准',
            routes: [
              {
                path: '/dd/s/contents',
                name: '现行标准',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../Standard/contents'),
                      LoadingComponent: require('/Users/qinhaitao/Documents/hyex/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../Standard/contents').default,
                exact: true,
              },
              {
                path: '/dd/s/fdonitohgfdjtyrr',
                name: '标准信息',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../Standard/contents'),
                      LoadingComponent: require('/Users/qinhaitao/Documents/hyex/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../Standard/contents').default,
                exact: true,
              },
              {
                path: '/dashboard/monihfghtor',
                name: '有效软件目录',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      app: require('@tmp/dva').getApp(),
                      models: () => [
                        import(/* webpackChunkName: 'p__Dashboard__models__activities.js' */ '/Users/qinhaitao/Documents/hyex/src/pages/Dashboard/models/activities.js').then(
                          m => {
                            return { namespace: 'activities', ...m.default };
                          },
                        ),
                        import(/* webpackChunkName: 'p__Dashboard__models__chart.js' */ '/Users/qinhaitao/Documents/hyex/src/pages/Dashboard/models/chart.js').then(
                          m => {
                            return { namespace: 'chart', ...m.default };
                          },
                        ),
                        import(/* webpackChunkName: 'p__Dashboard__models__monitor.js' */ '/Users/qinhaitao/Documents/hyex/src/pages/Dashboard/models/monitor.js').then(
                          m => {
                            return { namespace: 'monitor', ...m.default };
                          },
                        ),
                      ],
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../Dashboard/Analysis'),
                      LoadingComponent: require('/Users/qinhaitao/Documents/hyex/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../Dashboard/Analysis').default,
                exact: true,
              },
              {
                component: () =>
                  React.createElement(
                    require('/Users/qinhaitao/Documents/hyex/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                      .default,
                    { pagesPath: 'src/pages', hasRoutesInConfig: true },
                  ),
              },
            ],
          },
          {
            component: () =>
              React.createElement(
                require('/Users/qinhaitao/Documents/hyex/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                  .default,
                { pagesPath: 'src/pages', hasRoutesInConfig: true },
              ),
          },
        ],
      },
      {
        path: 'http://www1.hyec.com:8085/',
        target: '_blank',
        name: '知识经验KM',
        icon: 'cluster',
        exact: true,
      },
      {
        path: 'http://www1.hyec.com:8082/',
        target: '_blank',
        name: '人力资源HRS',
        icon: 'read',
        exact: true,
      },
      {
        path: 'http://cba.hyec.com/',
        target: '_blank',
        name: '薪资查询CBA',
        icon: 'money-collect',
        exact: true,
      },
      {
        path: 'http://tds.hyec.com/Login',
        target: '_blank',
        name: '人才发展TDS',
        icon: 'usergroup-add',
        exact: true,
      },
      {
        path: 'http://www1.hyec.com:8087/AMS/it/user/login.asp',
        target: '_blank',
        name: '办公资产AMS',
        icon: 'audit',
        exact: true,
      },
      {
        path: 'http://10.43.1.100:8085/',
        target: '_blank',
        name: '项目网站',
        icon: 'link',
        exact: true,
      },
      {
        path: '/other',
        name: '其它应用程序',
        icon: 'ellipsis',
        routes: [
          {
            path: '/other/link',
            name: '友情链接',
            component: __IS_BROWSER
              ? _dvaDynamic({
                  component: () =>
                    import(/* webpackChunkName: "p__Other__Link" */ '../Other/Link'),
                  LoadingComponent: require('/Users/qinhaitao/Documents/hyex/src/components/PageLoading/index')
                    .default,
                })
              : require('../Other/Link').default,
            exact: true,
          },
          {
            component: () =>
              React.createElement(
                require('/Users/qinhaitao/Documents/hyex/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                  .default,
                { pagesPath: 'src/pages', hasRoutesInConfig: true },
              ),
          },
        ],
      },
      {
        path: '/dashboard/monitxcvcxvcor',
        name: '子公司',
        icon: 'link',
        routes: [
          {
            path: '/dashboard/monivxcvvcxxctor',
            name: '上海市工业用水技术中心',
            component: __IS_BROWSER
              ? _dvaDynamic({
                  app: require('@tmp/dva').getApp(),
                  models: () => [
                    import(/* webpackChunkName: 'p__Dashboard__models__activities.js' */ '/Users/qinhaitao/Documents/hyex/src/pages/Dashboard/models/activities.js').then(
                      m => {
                        return { namespace: 'activities', ...m.default };
                      },
                    ),
                    import(/* webpackChunkName: 'p__Dashboard__models__chart.js' */ '/Users/qinhaitao/Documents/hyex/src/pages/Dashboard/models/chart.js').then(
                      m => {
                        return { namespace: 'chart', ...m.default };
                      },
                    ),
                    import(/* webpackChunkName: 'p__Dashboard__models__monitor.js' */ '/Users/qinhaitao/Documents/hyex/src/pages/Dashboard/models/monitor.js').then(
                      m => {
                        return { namespace: 'monitor', ...m.default };
                      },
                    ),
                  ],
                  component: () =>
                    import(/* webpackChunkName: "p__Dashboard__Analysis" */ '../Dashboard/Analysis'),
                  LoadingComponent: require('/Users/qinhaitao/Documents/hyex/src/components/PageLoading/index')
                    .default,
                })
              : require('../Dashboard/Analysis').default,
            exact: true,
          },
          {
            path: '/dashboard/monifftor',
            name: '上海华谊工程技术有限公司',
            component: __IS_BROWSER
              ? _dvaDynamic({
                  app: require('@tmp/dva').getApp(),
                  models: () => [
                    import(/* webpackChunkName: 'p__Dashboard__models__activities.js' */ '/Users/qinhaitao/Documents/hyex/src/pages/Dashboard/models/activities.js').then(
                      m => {
                        return { namespace: 'activities', ...m.default };
                      },
                    ),
                    import(/* webpackChunkName: 'p__Dashboard__models__chart.js' */ '/Users/qinhaitao/Documents/hyex/src/pages/Dashboard/models/chart.js').then(
                      m => {
                        return { namespace: 'chart', ...m.default };
                      },
                    ),
                    import(/* webpackChunkName: 'p__Dashboard__models__monitor.js' */ '/Users/qinhaitao/Documents/hyex/src/pages/Dashboard/models/monitor.js').then(
                      m => {
                        return { namespace: 'monitor', ...m.default };
                      },
                    ),
                  ],
                  component: () =>
                    import(/* webpackChunkName: "p__Dashboard__Analysis" */ '../Dashboard/Analysis'),
                  LoadingComponent: require('/Users/qinhaitao/Documents/hyex/src/components/PageLoading/index')
                    .default,
                })
              : require('../Dashboard/Analysis').default,
            exact: true,
          },
          {
            component: () =>
              React.createElement(
                require('/Users/qinhaitao/Documents/hyex/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                  .default,
                { pagesPath: 'src/pages', hasRoutesInConfig: true },
              ),
          },
        ],
      },
      {
        component: () =>
          React.createElement(
            require('/Users/qinhaitao/Documents/hyex/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
              .default,
            { pagesPath: 'src/pages', hasRoutesInConfig: true },
          ),
      },
    ],
  },
  {
    component: () =>
      React.createElement(
        require('/Users/qinhaitao/Documents/hyex/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
          .default,
        { pagesPath: 'src/pages', hasRoutesInConfig: true },
      ),
  },
];
window.g_routes = routes;
const plugins = require('umi/_runtimePlugin');
plugins.applyForEach('patchRoutes', { initialValue: routes });

export { routes };

export default class RouterWrapper extends React.Component {
  unListen() {}

  constructor(props) {
    super(props);

    // route change handler
    function routeChangeHandler(location, action) {
      plugins.applyForEach('onRouteChange', {
        initialValue: {
          routes,
          location,
          action,
        },
      });
    }
    this.unListen = history.listen(routeChangeHandler);
    routeChangeHandler(history.location);
  }

  componentWillUnmount() {
    this.unListen();
  }

  render() {
    const props = this.props || {};
    return (
      <RendererWrapper0>
        <Router history={history}>{renderRoutes(routes, props)}</Router>
      </RendererWrapper0>
    );
  }
}
