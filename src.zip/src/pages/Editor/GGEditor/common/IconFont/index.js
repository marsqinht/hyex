import { Icon } from 'antd';

const IconFont = Icon.createFromIconfontCN({
  scriptUrl: 'https://at.alicdn.com/t/font_1101588_01zniftxm9yp.js',
});

export default IconFont;
